cordova.define("cordova-plugin-sino-xhcc-ocr.sino-xhcc-ocr", function(require, exports, module) {
var exec = require('cordova/exec');

module.exports = {
ocr:function(cardType,onSuccess,onError){
    var params = {
        cardType : 2,//证件类型
    };
    
    if(cardType) params.cardType = cardType;
    exec(onSuccess,onError, 'SinoXinHucOCR', 'scan', [params]);
}
};

});
