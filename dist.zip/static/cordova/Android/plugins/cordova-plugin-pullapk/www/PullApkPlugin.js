cordova.define("cordova-plugin-pullapk.PullApkPlugin", function(require, exports, module) {
var exec = require('cordova/exec');

/**
 * 拉起 理赔的方法
 */
exports.pullLp = function (arg0, success, error) {
    exec(success, error, 'PullApkPlugin', 'pullLp', arg0);
};


/**
 * 拉起 保全的方法
 */
exports.pullBq = function (arg0, success, error) {
    exec(success, error, 'PullApkPlugin', 'pullBq', arg0);
};

});
