cordova.define("cordova-magnum-plugin.MagnumPlugin", function(require, exports, module) {
var exec = require('cordova/exec');

function MagnumPlugin() {}

function MagnumMethod(name, args, completion) {
  exec(
    function(result) {
      if (completion) {
        var answerParsed = JSON.parse(result);
        var error = null;
        if (!answerParsed.Success) {
          var errorObj = answerParsed.ApiErrorObject;
          error = {
            ErrorObject: {
              MessageCode: errorObj.ErrorObject.MessageCode,
              Message: errorObj.ErrorObject.Message,
              FullText: errorObj.ErrorObject.FullText,
              Parameter: errorObj.ErrorObject.Parameter,
              ScreenOrientation: errorObj.ErrorObject.ScreenOrientation,
              ScreenRotation: errorObj.ErrorObject.ScreenRotation
            },
            DeviceInfo: errorObj.DeviceInfo,
            CaseModel: errorObj.CaseModel,
            VersionInfo: errorObj.VersionInfo
          };
          console.error('MagnumPlugin: Engine error: ');
          console.error(error);
        }
        completion(answerParsed.Data, error);
      }
    },
    function(result) {
      console.error('MagnumPlugin: Error in native call: ');
      console.error(result);
      if (completion) {
        completion(null, result);
      }
    },
    'MagnumPlugin',
    'magnumMethod',
    [name, JSON.stringify(args)]
  );
}

function resolveUiVersion(callback) {
  window.resolveLocalFileSystemURL(
    cordova.file.applicationDirectory + '/www/magnum-ui/package.properties',
    function(fileEntry) {
      fileEntry.file(
        function(file) {
          var reader = new FileReader();
          reader.onloadend = function(e) {
            callback(e.target.result.match(/package\.version=(.*)/)[1]);
          };
          reader.readAsText(file);
        },
        function(err) {
          console.error(err);
          callback('failed to read "package.properties" file content');
        }
      );
    },
    function(err) {
      console.error(err);
      callback('failed to access "package.properties" file');
    }
  );
}

// Startup
MagnumPlugin.prototype.startup = function(dbEncryptionKey, completion) {
  resolveUiVersion(function(uiVersion) {
    var startupParamsJSON = JSON.stringify({
      dbEncryptionKey: dbEncryptionKey,
      uiVersion: uiVersion
    });
    MagnumMethod('startup', [startupParamsJSON], completion);
  });
};

// Common
MagnumPlugin.prototype.getVersion = function(completion) {
  MagnumMethod('getVersion', [], completion);
};

MagnumPlugin.prototype.getLanguages = function(completion) {
  MagnumMethod('getLanguages', [], completion);
};

MagnumPlugin.prototype.getLogRecords = function(completion) {
  MagnumMethod('getLogRecords', [], completion);
};

MagnumPlugin.prototype.eraseData = function(completion) {
  MagnumMethod('eraseData', [], completion);
};

MagnumPlugin.prototype.syncJson = function(rulebaseJson, completion) {
  MagnumMethod('syncJson', [rulebaseJson], completion);
};

MagnumPlugin.prototype.syncRulebaseFromPath = function(rulebasePath, completion) {
  MagnumMethod('syncRulebaseFromPath', [rulebasePath], completion);
};

// Cases: Common
MagnumPlugin.prototype.getCases = function(completion) {
  MagnumMethod('getCases', [], completion);
};

// Case: Operations
MagnumPlugin.prototype.startCase = function(bootstrapJson, caseId, languageCode, completion) {
  MagnumMethod('startCase', [bootstrapJson, caseId, languageCode], completion);
};

MagnumPlugin.prototype.resumeCase = function(caseId, completion) {
  MagnumMethod('resumeCase', [caseId], completion);
};

MagnumPlugin.prototype.deleteCase = function(caseId, completion) {
  MagnumMethod('deleteCase', [caseId], completion);
};

MagnumPlugin.prototype.exportCase = function(caseId, completion) {
  MagnumMethod('exportCase', [caseId], completion);
};

MagnumPlugin.prototype.importCase = function(importJson, overwrite, completion) {
  MagnumMethod('importCase', [importJson, overwrite], completion);
};

MagnumPlugin.prototype.getSubmitPackage = function(caseId, withRulebaseUuid, completion) {
  if (!!withRulebaseUuid !== withRulebaseUuid) {
    withRulebaseUuid = true;
  }
  var getSDPMethodName = withRulebaseUuid ? 'getSubmitPackage' : 'getSubmitPackageWithoutUuid';
  MagnumMethod(getSDPMethodName, [caseId], completion);
};

MagnumPlugin.prototype.getCompositeSubmitPackage = function(caseId, withRulebaseUuid, completion) {
  if (!!withRulebaseUuid !== withRulebaseUuid) {
    withRulebaseUuid = true;
  }
  var getCompositeSDPMethodName = withRulebaseUuid ? 'getCompositeSubmitPackage' : 'getCompositeSubmitPackageWithoutUuid';
  MagnumMethod(getCompositeSDPMethodName, [caseId], completion);
};

MagnumPlugin.prototype.getCaseAnswers = function(caseId, completion) {
  MagnumMethod('getCaseAnswers', [caseId], completion);
};

// Case: Get/Set status/userdata
MagnumPlugin.prototype.getCaseStatus = function(caseId, completion) {
  MagnumMethod('getCaseStatus', [caseId], completion);
};

MagnumPlugin.prototype.setCaseStatus = function(caseId, status, userData, completion) {
  MagnumMethod('setCaseStatus', [caseId, status, userData], completion);
};

MagnumPlugin.prototype.getUserData = function(caseId, completion) {
  MagnumMethod('getUserData', [caseId], completion);
};

MagnumPlugin.prototype.setUserData = function(caseId, userData, completion) {
  MagnumMethod('setUserData', [caseId, userData], completion);
};

MagnumPlugin.prototype.getNavigationForLife = function(caseId, lifeIndex, completion) {
  MagnumMethod('getNavigationForLife', [caseId, lifeIndex], completion);
};

MagnumPlugin.prototype.UI = {
  getFormForNavigation: function(navId, navIndex, caseId, lifeIndex, completion) {
    MagnumMethod('getFormForNavigation', [navId, navIndex, caseId, lifeIndex], completion);
  },
  saveForm: function(formModelJson, caseId, lifeIndex, completion) {
    MagnumMethod('saveForm', [JSON.stringify(formModelJson), caseId, lifeIndex], completion);
  },
  saveErrorRecord: function(errorMessage, errorCode, errorStacktrace, completion) {
    MagnumMethod('saveLogRecord', [errorMessage, errorCode, errorStacktrace], completion);
  },
  getDataModel: function(caseId, completion) {
    MagnumMethod('getCaseDataModel', [caseId], completion);
  },
  processAnswers: function(answerModelsJson, caseId, lifeIndex, navigationUuid, completion) {
    MagnumMethod('processQuestions', [JSON.stringify(answerModelsJson), caseId, lifeIndex, navigationUuid], completion);
  },
  confirmCase: function(caseId, completion) {
    MagnumMethod('applyCase', [caseId], completion);
  }
};

var MagnumPlugin = new MagnumPlugin();
module.exports = MagnumPlugin;

});
